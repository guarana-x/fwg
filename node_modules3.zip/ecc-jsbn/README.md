ecc-jsbn
========

ECC package based on [jsbn](https://github.com/andyperlitch/jsbn) from [Tom Wu](http://www-cs-students.stanford.edu/~tjw/).

This is a subset of the same interface as the [node compiled module](https://github.com/quartzjer/ecc), but works in the browser too.

Also uses point compression now from [https://github.com/kaielvin](https://github.com/kaielvin/jsbn-ec-point-compression).
