has-binarydata.js
=================

Simple module to test if an object contains binary data
